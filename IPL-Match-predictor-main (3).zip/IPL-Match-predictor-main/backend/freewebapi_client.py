"""
FreeWebAPI Cricket API client for fetching IPL data.

Backup data source for:
- Team standings/points table
- Team squads

API Documentation: https://freeapi.app/
Note: This is a placeholder implementation. Actual endpoints need to be configured based on API documentation.
"""

import logging
from typing import Dict, Optional
from datetime import datetime, timezone

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

logger = logging.getLogger(__name__)

# API Configuration
FREEWEBAPI_BASE = "https://api.freeapi.app/api/v1"

HEADERS = {
    "User-Agent": "IPL-Match-Predictor/1.0",
    "Accept": "application/json",
}


def _now() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_int(value, default=0) -> int:
    """Safely convert value to int."""
    try:
        return int(value)
    except (ValueError, TypeError, AttributeError):
        return default


def _safe_float(value, default=0.0) -> float:
    """Safely convert value to float."""
    try:
        return float(value)
    except (ValueError, TypeError, AttributeError):
        return default


def fetch_standings() -> Optional[Dict]:
    """
    Fetch IPL standings/points table from FreeWebAPI Cricket API.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for FreeWebAPI")
        return None

    try:
        # Construct API endpoint for IPL standings
        # Note: Actual endpoint needs to be determined from FreeWebAPI documentation
        url = f"{FREEWEBAPI_BASE}/cricket/ipl/standings"

        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse standings from response
        if data.get("success") and "data" in data:
            standings = []
            teams_data = data.get("data", {}).get("standings", [])

            for team_data in teams_data:
                standings.append({
                    "team": team_data.get("teamCode", ""),
                    "name": team_data.get("teamName", ""),
                    "matches": _safe_int(team_data.get("matchesPlayed")),
                    "wins": _safe_int(team_data.get("wins")),
                    "losses": _safe_int(team_data.get("losses")),
                    "points": _safe_int(team_data.get("points")),
                    "nrr": _safe_float(team_data.get("netRunRate")),
                })

            return {
                "source": "freewebapi",
                "data": standings,
                "timestamp": _now(),
            }

        logger.warning("FreeWebAPI returned unsuccessful status or no data")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("FreeWebAPI request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching standings from FreeWebAPI: %s", exc)
        return None


def fetch_squads(team_short: Optional[str] = None) -> Optional[Dict]:
    """
    Fetch IPL team squads from FreeWebAPI Cricket API.

    Args:
        team_short: Optional team short code (e.g., 'MI', 'CSK'). If None, fetch all squads.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for FreeWebAPI")
        return None

    try:
        # Construct API endpoint for IPL squads
        url = f"{FREEWEBAPI_BASE}/cricket/ipl/squads"
        params = {}

        if team_short:
            params["team"] = team_short.upper()

        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse squads from response
        if data.get("success") and "data" in data:
            squads = {}
            teams_data = data.get("data", {}).get("teams", [])

            for team_info in teams_data:
                team_code = team_info.get("teamCode", "")

                # If specific team requested, filter
                if team_short and team_code.upper() != team_short.upper():
                    continue

                players = []
                for player in team_info.get("squad", []):
                    players.append({
                        "name": player.get("playerName", ""),
                        "role": player.get("role", ""),
                        "is_overseas": player.get("isOverseas", False),
                    })

                squads[team_code] = {
                    "team": team_code,
                    "name": team_info.get("teamName", ""),
                    "players": players,
                }

            return {
                "source": "freewebapi",
                "data": squads if not team_short else squads.get(team_short.upper()),
                "timestamp": _now(),
            }

        logger.warning("FreeWebAPI returned unsuccessful status or no data")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("FreeWebAPI request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching squads from FreeWebAPI: %s", exc)
        return None
