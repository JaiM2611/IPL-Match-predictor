import os
import logging
from typing import Optional
from flask import Flask, jsonify, request
from flask_cors import CORS

from backend.predictor import IPLPredictor
from backend import espncricinfo_client
from backend import data_aggregator
from services import cricket_api

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder="../frontend", static_url_path="")
CORS(app)

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
predictor = IPLPredictor(DATA_DIR)


# ── Serve frontend ──────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return app.send_static_file("index.html")


# ── Teams & venues ───────────────────────────────────────────────────────────────

@app.route("/api/teams", methods=["GET"])
def get_teams():
    return jsonify(predictor.get_all_teams())


@app.route("/api/venues", methods=["GET"])
def get_venues():
    return jsonify(predictor.get_all_venues())


@app.route("/api/squad/<team_short>", methods=["GET"])
def get_squad(team_short: str):
    squad = predictor.get_team_squad(team_short.upper())
    if not squad:
        return jsonify({"error": "Team not found"}), 404
    return jsonify(squad)


@app.route("/api/h2h/<team1>/<team2>", methods=["GET"])
def get_h2h(team1: str, team2: str):
    data = predictor.get_h2h(team1.upper(), team2.upper())
    return jsonify(data)


# ── Prediction ───────────────────────────────────────────────────────────────────

@app.route("/api/predict", methods=["POST"])
def predict():
    body = request.get_json(force=True)
    if not body:
        return jsonify({"error": "No JSON body provided"}), 400

    required = ["team1", "team2", "venue"]
    for field in required:
        if field not in body:
            return jsonify({"error": f"Missing required field: {field}"}), 400

    # Normalise
    body["team1"] = body["team1"].upper()
    body["team2"] = body["team2"].upper()

    if body["team1"] == body["team2"]:
        return jsonify({"error": "team1 and team2 must be different"}), 400

    result = predictor.predict(body)
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result)


# ── Live / ESPNcricinfo data ──────────────────────────────────────────────────────

@app.route("/api/injuries", methods=["GET"])
def get_injuries():
    data = espncricinfo_client.fetch_injury_updates()
    return jsonify(data)


@app.route("/api/points-table", methods=["GET"])
def get_points_table():
    data = espncricinfo_client.fetch_points_table()
    return jsonify(data)


@app.route("/api/upcoming-matches", methods=["GET"])
def get_upcoming_matches():
    data = espncricinfo_client.fetch_upcoming_matches()
    return jsonify(data)


# ── Enhanced data endpoints (multi-source aggregation) ───────────────────────────

@app.route("/api/v2/standings", methods=["GET"])
def get_standings_v2():
    """
    Get IPL standings with cascading fallback across multiple sources.

    Sources (in priority order):
    1. Cric API
    2. FreeWebAPI Cricket API
    3. ESPNcricinfo
    """
    data = data_aggregator.fetch_team_standings()
    return jsonify(data)


@app.route("/api/v2/squads", methods=["GET"])
@app.route("/api/v2/squads/<team_short>", methods=["GET"])
def get_squads_v2(team_short: Optional[str] = None):
    """
    Get IPL team squads with cascading fallback.

    Args:
        team_short: Optional team code (e.g., 'MI', 'CSK')

    Sources (in priority order):
    1. Cric API
    2. FreeWebAPI Cricket API
    3. Local cached data
    """
    if team_short:
        team_short = team_short.upper()

    data = data_aggregator.fetch_team_squads(team_short)
    return jsonify(data)


@app.route("/api/v2/injuries", methods=["GET"])
def get_injuries_v2():
    """
    Get IPL injury updates with cascading fallback.

    Sources (in priority order):
    1. General News API
    2. GNews API
    3. TheSportsDB
    4. ESPNcricinfo
    """
    data = data_aggregator.fetch_injury_updates()
    return jsonify(data)


@app.route("/api/v2/team-news", methods=["GET"])
def get_team_news_v2():
    """
    Get general IPL team news with cascading fallback.

    Sources (in priority order):
    1. General News API
    2. GNews API
    """
    data = data_aggregator.fetch_team_news()
    return jsonify(data)


@app.route("/api/v2/summary", methods=["GET"])
def get_data_summary():
    """
    Get comprehensive IPL data summary including:
    - Team standings
    - Injury updates
    - General team news

    All with appropriate source attribution.
    """
    data = data_aggregator.get_data_summary()
    return jsonify(data)


# ── Cricket data service endpoints ───────────────────────────────────────────

@app.route("/api/v2/cricket/series-id", methods=["GET"])
def get_cricket_series_id():
    """Dynamically resolve the IPL 2026 series ID from CricAPI."""
    from datetime import datetime, timezone
    series_id = cricket_api.get_series_id()
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    if series_id:
        return jsonify({"series_id": series_id, "timestamp": timestamp})
    return jsonify({"error": "Could not resolve series ID", "series_id": None}), 503


@app.route("/api/v2/cricket/schedule", methods=["GET"])
def get_cricket_schedule():
    """Get the IPL 2026 match schedule from CricAPI."""
    return jsonify(cricket_api.get_schedule())


@app.route("/api/v2/cricket/points-table", methods=["GET"])
def get_cricket_points_table():
    """Get the IPL 2026 points table from CricAPI."""
    return jsonify(cricket_api.get_points_table())


@app.route("/api/v2/cricket/live-matches", methods=["GET"])
def get_cricket_live_matches():
    """Get currently live cricket matches from CricAPI."""
    return jsonify(cricket_api.get_live_matches())


@app.route("/api/v2/cricket/teams", methods=["GET"])
def get_cricket_teams():
    """Get all cricket teams from CricAPI."""
    return jsonify(cricket_api.get_team_info())


# ── python-espncricinfo library endpoints ────────────────────────────────────────

@app.route("/api/v2/espncricinfo/live", methods=["GET"])
def get_espncricinfo_live():
    """
    Fetch live / recent cricket matches from ESPN Cricinfo using the
    python-espncricinfo library (Playwright/WebKit).

    Accepts an optional ``date`` query parameter (``YYYY-MM-DD``) to retrieve
    matches for a specific day.  Defaults to today.

    Returns a list of lightweight match references (``match_id`` + ``series_id``).
    Use ``/api/v2/espncricinfo/match/<series_id>/<match_id>`` to hydrate details.
    """
    match_date = request.args.get("date")
    data = espncricinfo_client.fetch_live_matches(match_date=match_date)
    return jsonify(data)


@app.route("/api/v2/espncricinfo/match/<int:series_id>/<int:match_id>", methods=["GET"])
def get_espncricinfo_match(series_id: int, match_id: int):
    """
    Fetch detailed scorecard / match information from ESPN Cricinfo using the
    python-espncricinfo library.

    The ``series_id`` and ``match_id`` can be obtained from the
    ``/api/v2/espncricinfo/live`` endpoint or read directly from an
    ESPN Cricinfo match page URL.
    """
    data = espncricinfo_client.fetch_match_details(match_id=match_id, series_id=series_id)
    if data.get("source") == "error":
        return jsonify(data), 502
    return jsonify(data)


@app.route("/api/v2/espncricinfo/player/<int:player_id>", methods=["GET"])
def get_espncricinfo_player(player_id: int):
    """
    Fetch player profile information from ESPN Cricinfo using the
    python-espncricinfo library.

    The ``player_id`` is the numeric ID found in ESPN Cricinfo player URLs
    (e.g. Ajinkya Rahane is ``277916``).
    """
    data = espncricinfo_client.fetch_player_details(player_id=player_id)
    if data.get("source") == "error":
        return jsonify(data), 502
    return jsonify(data)


# ── Health check ─────────────────────────────────────────────────────────────────

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "teams_loaded": len(predictor.teams)})


# ── Cache management ─────────────────────────────────────────────────────────────

@app.route("/api/cache/clear", methods=["POST"])
def clear_cache():
    """Clear all cached data or specific key"""
    from backend.cache import clear_cache as do_clear

    body = request.get_json(silent=True) or {}
    key = body.get("key")

    result = do_clear(key)

    if key:
        return jsonify({
            "message": f"Cache cleared for key: {key}" if result else f"Key not found: {key}",
            "success": result
        })
    else:
        return jsonify({
            "message": "All cache cleared",
            "success": True
        })


@app.route("/api/cache/stats", methods=["GET"])
def get_cache_stats():
    """Get cache statistics"""
    from backend.cache import get_cache_stats

    stats = get_cache_stats()
    return jsonify({
        "cache_entries": len(stats),
        "entries": stats
    })


# ── Gemini Data Bridge endpoints ─────────────────────────────────────────────

@app.route("/api/v2/gemini-data", methods=["GET"])
def get_gemini_data():
    """
    Return the contents of the locally cached ``ipl_data.json`` file that is
    populated by the Gemini Data Bridge.

    The file is read from disk on every request so the UI always sees the
    latest version written by the background scheduler.
    """
    from backend.gemini_bridge import read_ipl_data
    data = read_ipl_data()
    if not data:
        return jsonify({
            "error": "No Gemini data available yet. Trigger a refresh or wait for the scheduler.",
            "data": {}
        }), 404
    return jsonify(data)


@app.route("/api/v2/gemini-data/refresh", methods=["POST"])
def refresh_gemini_data():
    """
    Manually trigger a Gemini data fetch and update ``ipl_data.json``.

    Useful for on-demand refreshes without waiting for the 6-hour scheduler
    interval.  The response contains the freshly fetched data.
    """
    from backend.gemini_bridge import update_ipl_data
    try:
        data = update_ipl_data()
        return jsonify({"message": "IPL data refreshed successfully.", "data": data})
    except Exception as exc:  # noqa: BLE001
        logger.error("Gemini data refresh failed: %s", exc)
        return jsonify({"error": str(exc)}), 500


# ── Scheduler start (auto-launch when running as __main__ or via gunicorn) ────

def _start_background_scheduler() -> None:
    """Start the Gemini update scheduler in a background thread."""
    try:
        from backend.scheduler import start_scheduler
        start_scheduler()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not start Gemini scheduler: %s", exc)


# Start the scheduler only when not in testing mode
if not os.environ.get("FLASK_TESTING"):
    _start_background_scheduler()


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
