"""
Cric API client for fetching IPL data.

Primary data source for:
- Team standings/points table
- Team squads

API Documentation: https://api.cricapi.com/
"""

import logging
import os
from typing import Dict, List, Optional
from datetime import datetime, timezone

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

logger = logging.getLogger(__name__)

# API Configuration
CRIC_API_BASE = "https://api.cricapi.com/v1"
CRIC_API_KEY = os.environ.get("CRIC_API_KEY", "f87d1825-d266-416f-b92e-c8a95bb07458")

HEADERS = {
    "User-Agent": "IPL-Match-Predictor/1.0",
    "Accept": "application/json",
}


def _now() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_int(value, default=0) -> int:
    """Safely convert value to int."""
    try:
        return int(value)
    except (ValueError, TypeError, AttributeError):
        return default


def _safe_float(value, default=0.0) -> float:
    """Safely convert value to float."""
    try:
        return float(value)
    except (ValueError, TypeError, AttributeError):
        return default


def fetch_standings() -> Optional[Dict]:
    """
    Fetch IPL standings/points table from Cric API.

    Uses the dynamically-resolved series ID from services.cricket_api.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for Cric API")
        return None

    if not CRIC_API_KEY:
        logger.warning("CRIC_API_KEY not configured")
        return None

    # Resolve series ID dynamically
    from services.cricket_api import get_series_id
    series_id = get_series_id()
    if not series_id:
        logger.warning("fetch_standings: could not resolve series ID")
        return None

    try:
        url = f"{CRIC_API_BASE}/series_info"
        params = {
            "apikey": CRIC_API_KEY,
            "id": series_id,
        }

        logger.info("Fetching standings with series ID: %s", series_id)
        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        if data.get("status") == "success" and "data" in data:
            standings = []
            points_table = data.get("data", {}).get("points_table", [])

            for team_data in points_table:
                standings.append({
                    "team": team_data.get("team_short", ""),
                    "name": team_data.get("team_name", ""),
                    "matches": _safe_int(team_data.get("played")),
                    "wins": _safe_int(team_data.get("won")),
                    "losses": _safe_int(team_data.get("lost")),
                    "points": _safe_int(team_data.get("points")),
                    "nrr": _safe_float(team_data.get("nrr")),
                })

            logger.info("Successfully fetched standings with series ID: %s", series_id)
            return {
                "source": "cric_api",
                "data": standings,
                "timestamp": _now(),
            }

        logger.debug("fetch_standings: no data in response for series ID %s", series_id)

    except requests.exceptions.RequestException as exc:
        logger.warning("fetch_standings request failed: %s", exc)
    except Exception as exc:
        logger.warning("fetch_standings error: %s", exc)

    logger.warning("fetch_standings: failed to retrieve standings")
    return None


def fetch_squads(team_short: Optional[str] = None) -> Optional[Dict]:
    """
    Fetch IPL team squads from Cric API.

    Uses the dynamically-resolved series ID from services.cricket_api.

    Args:
        team_short: Optional team short code (e.g., 'MI', 'CSK'). If None, fetch all squads.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for Cric API")
        return None

    if not CRIC_API_KEY:
        logger.warning("CRIC_API_KEY not configured")
        return None

    # Resolve series ID dynamically
    from services.cricket_api import get_series_id
    series_id = get_series_id()
    if not series_id:
        logger.warning("fetch_squads: could not resolve series ID")
        return None

    try:
        url = f"{CRIC_API_BASE}/series_squad"
        params = {
            "apikey": CRIC_API_KEY,
            "id": series_id,
        }

        logger.info("Fetching squads with series ID: %s", series_id)
        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        if data.get("status") == "success" and "data" in data:
            squads = {}
            teams_data = data.get("data", {}).get("teams", [])

            for team_info in teams_data:
                team_code = team_info.get("team_short", "")

                # If specific team requested, filter
                if team_short and team_code.upper() != team_short.upper():
                    continue

                players = []
                for player in team_info.get("players", []):
                    players.append({
                        "name": player.get("name", ""),
                        "role": player.get("role", ""),
                        "is_overseas": player.get("is_overseas", False),
                    })

                squads[team_code] = {
                    "team": team_code,
                    "name": team_info.get("team_name", ""),
                    "players": players,
                }

            logger.info("Successfully fetched squads with series ID: %s", series_id)
            return {
                "source": "cric_api",
                "data": squads if not team_short else squads.get(team_short.upper()),
                "timestamp": _now(),
            }

        logger.debug("fetch_squads: no data in response for series ID %s", series_id)

    except requests.exceptions.RequestException as exc:
        logger.warning("fetch_squads request failed: %s", exc)
    except Exception as exc:
        logger.warning("fetch_squads error: %s", exc)

    logger.warning("fetch_squads: failed to retrieve squads")
    return None
