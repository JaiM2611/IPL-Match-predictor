"""
Gemini Data Bridge Scheduler
=============================
Runs :func:`backend.gemini_bridge.update_ipl_data` automatically every 6 hours
using APScheduler's ``BackgroundScheduler``.

The scheduler is designed to be **embedded inside an existing Flask or Streamlit
process** (it runs in a background thread) so no separate worker process is
needed.

Usage – standalone
------------------
Run this module directly to keep the scheduler alive in a dedicated process::

    python -m backend.scheduler

Usage – embedded in Flask
-------------------------
Import and call :func:`start_scheduler` once when the Flask app starts up::

    from backend.scheduler import start_scheduler
    start_scheduler()

The scheduler will then execute :func:`update_ipl_data` every 6 hours and on
startup (``next_run_time=datetime.now()``).

Environment variables
---------------------
GEMINI_API_KEY : Required by the underlying bridge to call the Gemini API.
GEMINI_UPDATE_INTERVAL_HOURS : Optional override for the interval (default 6).
"""

from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

_scheduler = None  # module-level singleton so we don't start duplicates


def start_scheduler() -> None:
    """
    Start the APScheduler ``BackgroundScheduler`` that calls
    :func:`~backend.gemini_bridge.update_ipl_data` every
    ``GEMINI_UPDATE_INTERVAL_HOURS`` hours (default 6).

    Safe to call multiple times – subsequent calls are no-ops if the
    scheduler is already running.
    """
    global _scheduler  # noqa: PLW0603

    if _scheduler is not None and _scheduler.running:
        logger.info("Scheduler already running – skipping duplicate start.")
        return

    try:
        from apscheduler.schedulers.background import BackgroundScheduler  # lazy import
    except ImportError:
        logger.error(
            "APScheduler is not installed. "
            "Add 'apscheduler>=3.10.0' to requirements.txt and run pip install."
        )
        return

    from backend.gemini_bridge import update_ipl_data  # noqa: PLC0415

    interval_hours = int(os.environ.get("GEMINI_UPDATE_INTERVAL_HOURS", "6"))

    _scheduler = BackgroundScheduler(timezone="UTC")
    _scheduler.add_job(
        func=update_ipl_data,
        trigger="interval",
        hours=interval_hours,
        id="gemini_ipl_update",
        name="Gemini IPL Data Bridge",
        next_run_time=datetime.now(timezone.utc),  # run immediately on startup
        max_instances=1,
        coalesce=True,
    )
    _scheduler.start()
    logger.info(
        "Gemini IPL scheduler started – will run every %d hour(s).", interval_hours
    )


def stop_scheduler() -> None:
    """Gracefully shut down the scheduler if it is running."""
    global _scheduler  # noqa: PLW0603

    if _scheduler is not None and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("Gemini IPL scheduler stopped.")
    _scheduler = None


# ── CLI / standalone entry-point ──────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )

    start_scheduler()

    logger.info("Scheduler is running. Press Ctrl-C to exit.")
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        stop_scheduler()
        logger.info("Scheduler stopped by user.")
