"""
Deprecated: this module has been replaced by espncricinfo_client.

Cricbuzz was found to provide inaccurate and premature IPL 2026 data.
All functionality now lives in espncricinfo_client, which uses ESPNcricinfo
as the primary data source and includes tournament-date validation.

This shim re-exports the public API for backward compatibility only.
"""

from backend.espncricinfo_client import (  # noqa: F401  (re-export)
    fetch_injury_updates,
    fetch_points_table,
    fetch_upcoming_matches,
)
