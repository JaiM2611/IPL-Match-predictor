"""
General News API client for fetching IPL injury updates and team news.

Primary data source for:
- Player injury updates
- General team news

API Documentation: https://newsapi.org/
Note: Requires API key from newsapi.org
"""

import logging
import os
from typing import Dict, List, Optional
from datetime import datetime, timezone, timedelta

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

logger = logging.getLogger(__name__)

# API Configuration
NEWS_API_BASE = "https://newsapi.org/v2"
NEWS_API_KEY = os.environ.get("NEWS_API_KEY", "")

HEADERS = {
    "User-Agent": "IPL-Match-Predictor/1.0",
    "Accept": "application/json",
}

# Search keywords for filtering news
INJURY_KEYWORDS = ["injury", "injured", "unavailable", "ruled out", "doubtful", "fitness", "hurt"]
TEAM_NEWS_KEYWORDS = ["IPL", "Indian Premier League", "team news", "squad", "selection", "strategy"]


def _now() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _format_date(dt: datetime) -> str:
    """Format datetime for News API."""
    return dt.strftime("%Y-%m-%d")


def fetch_injury_updates() -> Optional[Dict]:
    """
    Fetch IPL player injury updates from News API.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for News API")
        return None

    if not NEWS_API_KEY:
        logger.warning("NEWS_API_KEY not configured")
        return None

    try:
        # Search for IPL injury news from the last 7 days
        url = f"{NEWS_API_BASE}/everything"
        from_date = datetime.now(timezone.utc) - timedelta(days=7)

        params = {
            "apiKey": NEWS_API_KEY,
            "q": "IPL AND (injury OR injured OR fitness OR unavailable)",
            "from": _format_date(from_date),
            "language": "en",
            "sortBy": "publishedAt",
            "pageSize": 20,
        }

        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse articles for injury information
        if data.get("status") == "ok" and "articles" in data:
            injuries = []

            for article in data.get("articles", []):
                title = article.get("title", "")
                description = article.get("description", "")
                content = article.get("content", "")
                published_at = article.get("publishedAt", "")

                # Combine text fields for analysis
                full_text = f"{title} {description} {content}".lower()

                # Check if article contains injury-related keywords
                if any(keyword in full_text for keyword in INJURY_KEYWORDS):
                    injuries.append({
                        "title": title,
                        "description": description,
                        "url": article.get("url", ""),
                        "published_at": published_at,
                        "source_name": article.get("source", {}).get("name", "Unknown"),
                    })

            return {
                "source": "news_api",
                "data": injuries,
                "timestamp": _now(),
                "count": len(injuries),
            }

        logger.warning("News API returned unsuccessful status or no articles")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("News API request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching injury updates from News API: %s", exc)
        return None


def fetch_team_news() -> Optional[Dict]:
    """
    Fetch general IPL team news from News API.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for News API")
        return None

    if not NEWS_API_KEY:
        logger.warning("NEWS_API_KEY not configured")
        return None

    try:
        # Search for IPL team news from the last 3 days
        url = f"{NEWS_API_BASE}/everything"
        from_date = datetime.now(timezone.utc) - timedelta(days=3)

        params = {
            "apiKey": NEWS_API_KEY,
            "q": "IPL OR \"Indian Premier League\"",
            "from": _format_date(from_date),
            "language": "en",
            "sortBy": "publishedAt",
            "pageSize": 30,
        }

        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse articles for team news
        if data.get("status") == "ok" and "articles" in data:
            news_items = []

            for article in data.get("articles", []):
                news_items.append({
                    "title": article.get("title", ""),
                    "description": article.get("description", ""),
                    "url": article.get("url", ""),
                    "published_at": article.get("publishedAt", ""),
                    "source_name": article.get("source", {}).get("name", "Unknown"),
                    "image_url": article.get("urlToImage"),
                })

            return {
                "source": "news_api",
                "data": news_items,
                "timestamp": _now(),
                "count": len(news_items),
            }

        logger.warning("News API returned unsuccessful status or no articles")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("News API request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching team news from News API: %s", exc)
        return None
