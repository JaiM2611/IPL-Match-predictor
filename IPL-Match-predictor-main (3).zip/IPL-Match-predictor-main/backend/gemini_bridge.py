"""
Gemini Data Bridge
==================
Automated updater that uses the Google Gemini API (with its built-in Google
Search grounding tool) to fetch real-time IPL 2026 data and persist it to a
local ``ipl_data.json`` file.

Fetched data categories
-----------------------
* Points Table
* Player Scorecards (top performers)
* Pitch Reports
* Injury Updates

The JSON file is *merged* (not overwritten) so that categories not covered by a
particular Gemini response retain their previous values.

Environment variables
---------------------
GEMINI_API_KEY : Google AI Studio / Vertex AI key for Gemini access (required).

Usage
-----
Run directly::

    python -m backend.gemini_bridge

Or import and call ``update_ipl_data()`` from your application.
"""

from __future__ import annotations

import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ── Path to the shared JSON store ────────────────────────────────────────────

_DATA_DIR = Path(__file__).parent / "data"
IPL_DATA_FILE = _DATA_DIR / "ipl_data.json"

# ── Prompts sent to Gemini ────────────────────────────────────────────────────

_PROMPTS: Dict[str, str] = {
    "points_table": (
        "Search for the current IPL 2026 points table. "
        "Return ONLY a valid JSON array where each element is an object with "
        "keys: team (string), matches (int), wins (int), losses (int), "
        "no_result (int), points (int), nrr (float). "
        "Do not include any explanation outside the JSON array."
    ),
    "player_scorecards": (
        "Search for IPL 2026 top player scorecards (batting and bowling). "
        "Return ONLY a valid JSON object with two keys: 'batting' and 'bowling'. "
        "Each is a list of objects with keys: player (string), team (string), "
        "runs_or_wickets (number), matches (int). "
        "Do not include any explanation outside the JSON object."
    ),
    "pitch_reports": (
        "Search for the latest IPL 2026 pitch reports for upcoming venues. "
        "Return ONLY a valid JSON array where each element has keys: "
        "venue (string), pitch_type (string), expected_behaviour (string), "
        "last_updated (string). "
        "Do not include any explanation outside the JSON array."
    ),
    "injuries": (
        "Search for IPL 2026 player injury news and updates. "
        "Return ONLY a valid JSON array where each element has keys: "
        "player (string), team (string), status (string), details (string). "
        "Do not include any explanation outside the JSON array."
    ),
}


# ── JSON helpers ──────────────────────────────────────────────────────────────

def _load_ipl_data() -> Dict[str, Any]:
    """Load existing ipl_data.json or return a fresh skeleton."""
    if IPL_DATA_FILE.exists():
        try:
            with IPL_DATA_FILE.open("r", encoding="utf-8") as fh:
                return json.load(fh)
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Could not read %s (%s) – starting fresh.", IPL_DATA_FILE, exc)
    return {}


def _save_ipl_data(data: Dict[str, Any]) -> None:
    """Persist *data* to ipl_data.json, creating parent directories if needed."""
    _DATA_DIR.mkdir(parents=True, exist_ok=True)
    with IPL_DATA_FILE.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
    logger.info("ipl_data.json saved (%d bytes)", IPL_DATA_FILE.stat().st_size)


def _merge_update(existing: Dict[str, Any], updates: Dict[str, Any]) -> Dict[str, Any]:
    """
    Shallow-merge *updates* into *existing*.

    Only keys present in *updates* are overwritten; all other keys in
    *existing* are preserved unchanged.
    """
    merged = dict(existing)
    merged.update(updates)
    return merged


def _extract_json(text: str) -> Optional[Any]:
    """
    Try to extract the first JSON value (object or array) from *text*.

    Gemini sometimes wraps JSON in markdown code fences or adds a brief preamble
    before the actual JSON payload.  This helper strips that noise.
    """
    # 1. Try to strip markdown code fences (```json … ```)
    fenced = re.search(r"```(?:json)?\s*([\s\S]+?)\s*```", text)
    if fenced:
        candidate = fenced.group(1).strip()
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass

    # 2. Find the first occurrence of '{' or '[' and use whichever comes first
    brace_pos = text.find("{")
    bracket_pos = text.find("[")

    # Build a list of (position, start_char, end_char) for candidates that exist
    candidates = []
    if brace_pos != -1:
        candidates.append((brace_pos, "{", "}"))
    if bracket_pos != -1:
        candidates.append((bracket_pos, "[", "]"))

    # Sort by position so we try the outermost / earliest JSON value first
    candidates.sort(key=lambda x: x[0])

    for start_pos, start_char, end_char in candidates:
        end_pos = text.rfind(end_char)
        if end_pos == -1 or end_pos <= start_pos:
            continue
        candidate = text[start_pos : end_pos + 1]
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue

    return None


# ── Gemini fetch ──────────────────────────────────────────────────────────────

def _fetch_with_gemini(category: str, prompt: str) -> Optional[Any]:
    """
    Call the Gemini API with Google Search grounding enabled and return the
    parsed JSON payload for *category*.

    Returns ``None`` on any error so the caller can skip updating that key.
    """
    api_key = os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        logger.error(
            "GEMINI_API_KEY environment variable is not set – skipping '%s'.", category
        )
        return None

    try:
        import google.generativeai as genai  # lazy import to avoid hard dep at module load
        from google.generativeai import types as genai_types
    except ImportError:
        logger.error(
            "google-generativeai is not installed. "
            "Add it to requirements.txt and run pip install."
        )
        return None

    try:
        genai.configure(api_key=api_key)

        # google_search_retrieval is the grounding tool that lets Gemini search the web
        google_search_tool = genai_types.Tool(
            google_search_retrieval=genai_types.GoogleSearchRetrieval()
        )

        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            tools=[google_search_tool],
        )

        response = model.generate_content(prompt)
        raw_text: str = response.text or ""
        logger.debug("Gemini raw response for '%s': %.200s…", category, raw_text)

        parsed = _extract_json(raw_text)
        if parsed is None:
            logger.warning(
                "Could not extract JSON from Gemini response for '%s'.", category
            )
        return parsed

    except Exception as exc:  # noqa: BLE001
        logger.error("Gemini fetch failed for '%s': %s", category, exc)
        return None


# ── Public API ────────────────────────────────────────────────────────────────

def update_ipl_data() -> Dict[str, Any]:
    """
    Fetch all IPL 2026 data categories from Gemini and merge them into the
    local ``ipl_data.json`` file.

    Returns the merged data dict (which is also written to disk).
    """
    logger.info("Starting IPL data update via Gemini…")

    existing = _load_ipl_data()
    updates: Dict[str, Any] = {
        "_last_updated": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "_source": "gemini-google-search",
    }

    for category, prompt in _PROMPTS.items():
        logger.info("Fetching category: %s", category)
        result = _fetch_with_gemini(category, prompt)
        if result is not None:
            updates[category] = result
            if isinstance(result, list):
                count_desc = f"{len(result)} items"
            elif isinstance(result, dict):
                count_desc = f"{sum(len(v) for v in result.values() if isinstance(v, list))} items across {len(result)} keys"
            else:
                count_desc = "1 item"
            logger.info("Updated '%s' (%s)", category, count_desc)
        else:
            logger.warning("Skipping '%s' – no data returned.", category)

    merged = _merge_update(existing, updates)
    _save_ipl_data(merged)
    logger.info("IPL data update complete.")
    return merged


def read_ipl_data() -> Dict[str, Any]:
    """
    Read and return the current contents of ``ipl_data.json``.

    Returns an empty dict if the file does not yet exist.
    """
    return _load_ipl_data()


# ── CLI entry-point ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
    )
    update_ipl_data()
