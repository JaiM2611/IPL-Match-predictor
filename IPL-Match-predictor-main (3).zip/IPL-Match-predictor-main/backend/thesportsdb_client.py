"""
TheSportsDB API client for fetching IPL injury updates and team information.

Additional backup data source for:
- Player injury updates
- Team information
- General sports news

API Documentation: https://www.thesportsdb.com/api.php
Note: Free tier available without API key, but limited functionality
"""

import logging
import os
from typing import Dict, Optional
from datetime import datetime, timezone

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

logger = logging.getLogger(__name__)

# API Configuration
THESPORTSDB_BASE = "https://www.thesportsdb.com/api/v1/json"
THESPORTSDB_API_KEY = os.environ.get("THESPORTSDB_API_KEY", "3")  # '3' is the free tier key

HEADERS = {
    "User-Agent": "IPL-Match-Predictor/1.0",
    "Accept": "application/json",
}

# IPL League ID in TheSportsDB
IPL_LEAGUE_ID = "4480"  # Indian Premier League


def _now() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def fetch_team_info(team_name: Optional[str] = None) -> Optional[Dict]:
    """
    Fetch IPL team information from TheSportsDB.

    Args:
        team_name: Optional team name to fetch specific team info.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for TheSportsDB")
        return None

    try:
        # Lookup teams in IPL league
        url = f"{THESPORTSDB_BASE}/{THESPORTSDB_API_KEY}/lookup_all_teams.php"
        params = {"id": IPL_LEAGUE_ID}

        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse team information
        if "teams" in data and data.get("teams"):
            teams = []

            for team in data.get("teams", []):
                team_info = {
                    "name": team.get("strTeam", ""),
                    "short_name": team.get("strTeamShort", ""),
                    "formed_year": team.get("intFormedYear"),
                    "stadium": team.get("strStadium", ""),
                    "description": team.get("strDescriptionEN", ""),
                    "badge": team.get("strTeamBadge"),
                    "jersey": team.get("strTeamJersey"),
                }

                # If specific team requested, filter
                if team_name and team_name.lower() not in team_info["name"].lower():
                    continue

                teams.append(team_info)

            return {
                "source": "thesportsdb",
                "data": teams if not team_name else teams[0] if teams else None,
                "timestamp": _now(),
            }

        logger.warning("TheSportsDB returned no team data")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("TheSportsDB request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching team info from TheSportsDB: %s", exc)
        return None


def fetch_latest_events() -> Optional[Dict]:
    """
    Fetch latest IPL events/matches from TheSportsDB.

    This can provide information about recent matches, which may include
    injury or team news context.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for TheSportsDB")
        return None

    try:
        # Fetch latest events for IPL league
        url = f"{THESPORTSDB_BASE}/{THESPORTSDB_API_KEY}/eventspastleague.php"
        params = {"id": IPL_LEAGUE_ID}

        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse events
        if "events" in data and data.get("events"):
            events = []

            for event in data.get("events", [])[:15]:  # Limit to last 15 events
                events.append({
                    "event_name": event.get("strEvent", ""),
                    "date": event.get("dateEvent", ""),
                    "time": event.get("strTime", ""),
                    "home_team": event.get("strHomeTeam", ""),
                    "away_team": event.get("strAwayTeam", ""),
                    "home_score": event.get("intHomeScore"),
                    "away_score": event.get("intAwayScore"),
                    "venue": event.get("strVenue", ""),
                    "status": event.get("strStatus", ""),
                })

            return {
                "source": "thesportsdb",
                "data": events,
                "timestamp": _now(),
            }

        logger.warning("TheSportsDB returned no event data")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("TheSportsDB request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching events from TheSportsDB: %s", exc)
        return None


def fetch_injury_updates() -> Optional[Dict]:
    """
    Attempt to fetch injury-related information from TheSportsDB.

    Note: TheSportsDB free tier has limited injury data. This function
    attempts to extract relevant information from team and event data.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    # TheSportsDB free tier doesn't have dedicated injury endpoints
    # We could potentially scrape from event descriptions or team info
    # For now, return None to indicate this source doesn't support injury data
    logger.info("TheSportsDB free tier doesn't provide dedicated injury updates")
    return None
