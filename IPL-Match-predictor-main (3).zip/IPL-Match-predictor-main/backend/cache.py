import time

CACHE = {}

CACHE_TTL = {
    "standings": 900,   # 15 min
    "injuries": 1800,   # 30 min
    "news": 1800,
    "squads": 3600      # 1 hour
}


def get_cache(key: str):
    entry = CACHE.get(key)
    if not entry:
        return None

    if time.time() - entry["time"] > CACHE_TTL.get(key, 900):
        return None

    return entry["data"]


def set_cache(key: str, data):
    CACHE[key] = {
        "data": data,
        "time": time.time()
    }


def is_valid(result):
    if not result:
        return False
    if "data" not in result:
        return False
    if not result["data"]:
        return False
    return True


def clear_cache(key: str = None):
    """Clear cache for a specific key or all keys if key is None"""
    if key:
        if key in CACHE:
            del CACHE[key]
            return True
        return False
    else:
        CACHE.clear()
        return True


def get_cache_stats():
    """Get statistics about current cache"""
    stats = {}
    current_time = time.time()
    for key, entry in CACHE.items():
        age = current_time - entry["time"]
        ttl = CACHE_TTL.get(key, 900)
        stats[key] = {
            "age_seconds": int(age),
            "ttl_seconds": ttl,
            "is_expired": age > ttl,
            "expires_in_seconds": max(0, int(ttl - age))
        }
    return stats
