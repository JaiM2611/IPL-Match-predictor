import logging
import time
from typing import Dict, List, Optional, Callable

from backend import cric_api_client
from backend import freewebapi_client
from backend import news_api_client
from backend import gnews_api_client
from backend import thesportsdb_client
from backend import espncricinfo_client
from backend.cache import get_cache, set_cache, is_valid

logger = logging.getLogger(__name__)


def _try_sources(
    sources: List[Callable],
    operation_name: str,
    cache_key: str
) -> Dict:

    # ✅ 1. Try cache first (only if not expired per TTL)
    cached = get_cache(cache_key)
    if cached:
        logger.info("Using valid cached %s", operation_name)
        return cached

    # ✅ 2. Try sources with retry
    for idx, source_func in enumerate(sources, 1):
        for attempt in range(2):
            try:
                logger.info(
                    "Attempt %d - %s from %s",
                    attempt + 1,
                    operation_name,
                    source_func.__module__.split(".")[-1]
                )

                result = source_func()

                if is_valid(result):
                    result["fetched_at"] = time.time()
                    set_cache(cache_key, result)
                    logger.info("Successfully fetched and cached %s from %s",
                              operation_name, source_func.__module__.split(".")[-1])
                    return result

            except Exception as exc:
                logger.warning(
                    "Retry %d failed for %s: %s",
                    attempt + 1,
                    operation_name,
                    exc
                )

            # Only sleep between retry attempts, not after last attempt
            if attempt < 1:
                time.sleep(1)

    # ❌ All sources failed, check for stale cache in raw dict
    # Note: get_cache already checked TTL, so we need to access raw cache
    from backend.cache import CACHE
    if cache_key in CACHE:
        stale_data = CACHE[cache_key]["data"]
        logger.warning("Returning stale/expired cache for %s", operation_name)
        # Mark as stale in response
        if isinstance(stale_data, dict):
            stale_data["is_stale"] = True
        return stale_data

    return {
        "source": "N/A",
        "data": [],
        "error": "All data sources unavailable",
    }


# ─────────────────────────────────────────────
# STANDINGS
# ─────────────────────────────────────────────

def fetch_team_standings() -> Dict:
    sources = [
        cric_api_client.fetch_standings,
        freewebapi_client.fetch_standings,
        # keep ESPN LAST only if needed
        espncricinfo_client.fetch_points_table,
    ]

    return _try_sources(sources, "team standings", "standings")


# ─────────────────────────────────────────────
# SQUADS
# ─────────────────────────────────────────────

def fetch_team_squads(team_short: Optional[str] = None) -> Dict:
    sources = [
        lambda: cric_api_client.fetch_squads(team_short),
        lambda: freewebapi_client.fetch_squads(team_short),
    ]

    return _try_sources(sources, "team squads", "squads")


# ─────────────────────────────────────────────
# INJURIES
# ─────────────────────────────────────────────

def fetch_injury_updates() -> Dict:
    sources = [
        news_api_client.fetch_injury_updates,
        gnews_api_client.fetch_injury_updates,
        thesportsdb_client.fetch_injury_updates,
        espncricinfo_client.fetch_injury_updates,
    ]

    return _try_sources(sources, "injuries", "injuries")


# ─────────────────────────────────────────────
# TEAM NEWS
# ─────────────────────────────────────────────

def fetch_team_news() -> Dict:
    sources = [
        news_api_client.fetch_team_news,
        gnews_api_client.fetch_team_news,
    ]

    return _try_sources(sources, "team news", "news")


# ─────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────

def get_data_summary() -> Dict:
    logger.info("Fetching IPL data summary")

    return {
        "standings": fetch_team_standings(),
        "injuries": fetch_injury_updates(),
        "team_news": fetch_team_news(),
        "_meta": {
            "cached": True,
            "note": "Data uses caching + multi-source fallback"
        }
    }
