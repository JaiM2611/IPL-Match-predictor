"""
GNews API client for fetching IPL injury updates and team news.

Backup data source for:
- Player injury updates
- General team news

API Documentation: https://gnews.io/
Note: Requires API key from gnews.io
"""

import logging
import os
from typing import Dict, Optional
from datetime import datetime, timezone

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

logger = logging.getLogger(__name__)

# API Configuration
GNEWS_API_BASE = "https://gnews.io/api/v4"
GNEWS_API_KEY = os.environ.get("GNEWS_API_KEY", "")

HEADERS = {
    "User-Agent": "IPL-Match-Predictor/1.0",
    "Accept": "application/json",
}

# Search keywords for filtering news
INJURY_KEYWORDS = ["injury", "injured", "unavailable", "ruled out", "doubtful", "fitness", "hurt"]


def _now() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def fetch_injury_updates() -> Optional[Dict]:
    """
    Fetch IPL player injury updates from GNews API.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for GNews API")
        return None

    if not GNEWS_API_KEY:
        logger.warning("GNEWS_API_KEY not configured")
        return None

    try:
        # Search for IPL injury news
        url = f"{GNEWS_API_BASE}/search"

        params = {
            "apikey": GNEWS_API_KEY,
            "q": "IPL injury OR IPL injured OR IPL fitness",
            "lang": "en",
            "country": "in",
            "max": 20,
            "sortby": "publishedAt",
        }

        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse articles for injury information
        if "articles" in data:
            injuries = []

            for article in data.get("articles", []):
                title = article.get("title", "")
                description = article.get("description", "")
                content = article.get("content", "")

                # Combine text fields for analysis
                full_text = f"{title} {description} {content}".lower()

                # Check if article contains injury-related keywords
                if any(keyword in full_text for keyword in INJURY_KEYWORDS):
                    injuries.append({
                        "title": title,
                        "description": description,
                        "url": article.get("url", ""),
                        "published_at": article.get("publishedAt", ""),
                        "source_name": article.get("source", {}).get("name", "Unknown"),
                    })

            return {
                "source": "gnews_api",
                "data": injuries,
                "timestamp": _now(),
                "count": len(injuries),
            }

        logger.warning("GNews API returned no articles")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("GNews API request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching injury updates from GNews API: %s", exc)
        return None


def fetch_team_news() -> Optional[Dict]:
    """
    Fetch general IPL team news from GNews API.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys, or None on failure.
    """
    if not REQUESTS_AVAILABLE:
        logger.warning("requests library not available for GNews API")
        return None

    if not GNEWS_API_KEY:
        logger.warning("GNEWS_API_KEY not configured")
        return None

    try:
        # Search for IPL team news
        url = f"{GNEWS_API_BASE}/search"

        params = {
            "apikey": GNEWS_API_KEY,
            "q": "IPL OR Indian Premier League",
            "lang": "en",
            "country": "in",
            "max": 30,
            "sortby": "publishedAt",
        }

        response = requests.get(url, params=params, headers=HEADERS, timeout=10)
        response.raise_for_status()

        data = response.json()

        # Parse articles for team news
        if "articles" in data:
            news_items = []

            for article in data.get("articles", []):
                news_items.append({
                    "title": article.get("title", ""),
                    "description": article.get("description", ""),
                    "url": article.get("url", ""),
                    "published_at": article.get("publishedAt", ""),
                    "source_name": article.get("source", {}).get("name", "Unknown"),
                    "image_url": article.get("image"),
                })

            return {
                "source": "gnews_api",
                "data": news_items,
                "timestamp": _now(),
                "count": len(news_items),
            }

        logger.warning("GNews API returned no articles")
        return None

    except requests.exceptions.RequestException as exc:
        logger.warning("GNews API request failed: %s", exc)
        return None
    except Exception as exc:
        logger.error("Unexpected error fetching team news from GNews API: %s", exc)
        return None
