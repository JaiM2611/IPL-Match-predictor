"""
ESPNcricinfo client for fetching real-time IPL data.

Replaces the previous Cricbuzz client, which was found to provide inaccurate
and premature IPL 2026 data (e.g. reporting player replacements before the
tournament had commenced).

Primary data source: python-espncricinfo library (outside-edge/python-espncricinfo),
which uses Playwright (WebKit) to bypass Akamai CDN restrictions and extract
embedded JSON from ESPN Cricinfo pages.

Fallback: BeautifulSoup-based web scraping for environments where the library
or Playwright WebKit is unavailable.

Attempts to fetch live data from ESPNcricinfo; falls back to cached data on
failure or when the tournament has not yet started.
"""

import logging
from typing import Dict, List, Optional, Union
from datetime import date, datetime, timezone

try:
    import requests
    from bs4 import BeautifulSoup
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

# python-espncricinfo library (outside-edge/python-espncricinfo)
try:
    from espncricinfo.match import Match
    from espncricinfo.match_ref import MatchRef
    from espncricinfo.summary import Summary
    from espncricinfo.player import Player
    from espncricinfo.series import Series
    ESPNCRICINFO_LIB_AVAILABLE = True
except ImportError:
    ESPNCRICINFO_LIB_AVAILABLE = False

logger = logging.getLogger(__name__)

ESPNCRICINFO_BASE = "https://www.espncricinfo.com"
ESPNCRICINFO_IPL_SCHEDULE = (
    f"{ESPNCRICINFO_BASE}/series/indian-premier-league-2026/match-schedule-fixtures"
)
ESPNCRICINFO_IPL_STANDINGS = (
    f"{ESPNCRICINFO_BASE}/series/indian-premier-league-2026/points-table-standings"
)
ESPNCRICINFO_IPL_NEWS = (
    f"{ESPNCRICINFO_BASE}/series/indian-premier-league-2026/cricket-news"
)

# IPL 2026 tournament start date — do not serve live player-movement data before this
IPL_2026_START_DATE = date(2026, 3, 25)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

# ---------------------------------------------------------------------------
# Fallback / cached data (used when live fetch is unavailable or premature)
# ---------------------------------------------------------------------------

FALLBACK_INJURY_DATA: List[Dict] = [
    {
        "player": "Jasprit Bumrah",
        "team": "MI",
        "status": "Available",
        "injury": None,
        "source": "cached",
    },
    {
        "player": "MS Dhoni",
        "team": "CSK",
        "status": "Available",
        "injury": None,
        "source": "cached",
    },
    {
        "player": "Virat Kohli",
        "team": "RCB",
        "status": "Available",
        "injury": None,
        "source": "cached",
    },
    {
        "player": "Rashid Khan",
        "team": "GT",
        "status": "Available",
        "injury": None,
        "source": "cached",
    },
]

FALLBACK_POINTS_TABLE: List[Dict] = [
    {"team": "KKR", "name": "Kolkata Knight Riders",       "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "CSK", "name": "Chennai Super Kings",          "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "GT",  "name": "Gujarat Titans",               "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "MI",  "name": "Mumbai Indians",               "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "RCB", "name": "Royal Challengers Bengaluru",  "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "SRH", "name": "Sunrisers Hyderabad",          "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "DC",  "name": "Delhi Capitals",               "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "RR",  "name": "Rajasthan Royals",             "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "PBKS", "name": "Punjab Kings",                "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
    {"team": "LSG", "name": "Lucknow Super Giants",         "matches": 0, "wins": 0, "losses": 0, "points": 0, "nrr": 0.000},
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tournament_has_started() -> bool:
    """Return True only after IPL 2026 has officially commenced."""
    return date.today() >= IPL_2026_START_DATE


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_int(value: str) -> int:
    try:
        return int(value.replace(",", "").strip())
    except (ValueError, AttributeError):
        return 0


def _safe_float(value: str) -> float:
    try:
        return float(value.strip())
    except (ValueError, AttributeError):
        return 0.0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def fetch_injury_updates() -> Dict:
    """
    Fetch player injury / availability updates from ESPNcricinfo.

    Returns cached pre-tournament roster data when the tournament has not yet
    commenced (preventing premature or speculative player-movement reports).
    Falls back to cached data if the live fetch fails.
    """
    if not _tournament_has_started():
        logger.info(
            "IPL 2026 has not yet started — returning pre-tournament roster "
            "rather than unverified injury speculation."
        )
        return {
            "source": "cached",
            "data": FALLBACK_INJURY_DATA,
            "timestamp": _now(),
            "note": "Tournament has not commenced; showing confirmed squad data.",
        }

    if not REQUESTS_AVAILABLE:
        logger.warning("requests/beautifulsoup4 not installed — using cached injury data.")
        return {"source": "cached", "data": FALLBACK_INJURY_DATA, "timestamp": _now()}

    try:
        resp = requests.get(ESPNCRICINFO_IPL_NEWS, headers=HEADERS, timeout=8)
        if resp.status_code != 200:
            raise ValueError(f"HTTP {resp.status_code}")

        soup = BeautifulSoup(resp.text, "lxml")
        articles = soup.select("article, div.ds-p-4, div[class*='story-card']")
        injuries = []
        for article in articles[:10]:
            text = article.get_text(separator=" ", strip=True)
            if any(kw in text.lower() for kw in ("injur", "unavail", "ruled out", "doubtful")):
                injuries.append({"text": text, "source": "espncricinfo"})

        if injuries:
            return {"source": "espncricinfo", "data": injuries, "timestamp": _now()}
        return {"source": "cached", "data": FALLBACK_INJURY_DATA, "timestamp": _now()}

    except Exception as exc:
        logger.warning("ESPNcricinfo fetch failed (%s) — using cached data.", exc)
        return {"source": "cached", "data": FALLBACK_INJURY_DATA, "timestamp": _now()}


def fetch_points_table() -> Dict:
    """
    Fetch the IPL 2026 points table from ESPNcricinfo.

    Returns a zeroed standings table when the tournament has not yet started,
    and falls back to cached data if the live fetch fails.
    """
    if not _tournament_has_started():
        logger.info("IPL 2026 has not yet started — returning pre-tournament standings.")
        return {
            "source": "cached",
            "data": FALLBACK_POINTS_TABLE,
            "timestamp": _now(),
            "note": "Tournament has not commenced; standings will be available after the first match.",
        }

    if not REQUESTS_AVAILABLE:
        logger.warning("requests not installed — using cached points table.")
        return {"source": "cached", "data": FALLBACK_POINTS_TABLE, "timestamp": _now()}

    try:
        resp = requests.get(ESPNCRICINFO_IPL_STANDINGS, headers=HEADERS, timeout=8)
        if resp.status_code != 200:
            raise ValueError(f"HTTP {resp.status_code}")

        soup = BeautifulSoup(resp.text, "lxml")
        rows = soup.select("table tr, div[class*='standings'] div[class*='row']")
        table = []
        for row in rows[1:]:
            cols = row.select("td")
            if len(cols) >= 6:
                table.append({
                    "team": cols[0].get_text(strip=True),
                    "matches": _safe_int(cols[1].get_text(strip=True)),
                    "wins": _safe_int(cols[2].get_text(strip=True)),
                    "losses": _safe_int(cols[3].get_text(strip=True)),
                    "points": _safe_int(cols[5].get_text(strip=True)),
                    "nrr": _safe_float(cols[6].get_text(strip=True)) if len(cols) > 6 else 0.0,
                    "source": "espncricinfo",
                })

        if table:
            return {"source": "espncricinfo", "data": table, "timestamp": _now()}
        return {"source": "cached", "data": FALLBACK_POINTS_TABLE, "timestamp": _now()}

    except Exception as exc:
        logger.warning("ESPNcricinfo points table fetch failed (%s) — using cached data.", exc)
        return {"source": "cached", "data": FALLBACK_POINTS_TABLE, "timestamp": _now()}


def fetch_upcoming_matches() -> Dict:
    """
    Fetch upcoming IPL 2026 matches from ESPNcricinfo.

    Falls back to the known pre-announced schedule if the live fetch fails.
    """
    if not REQUESTS_AVAILABLE:
        return {"source": "cached", "data": _fallback_upcoming(), "timestamp": _now()}

    try:
        resp = requests.get(ESPNCRICINFO_IPL_SCHEDULE, headers=HEADERS, timeout=8)
        if resp.status_code != 200:
            raise ValueError(f"HTTP {resp.status_code}")

        soup = BeautifulSoup(resp.text, "lxml")
        match_cards = soup.select(
            "div[class*='match-card'], div[class*='fixture'], article"
        )
        upcoming = []
        for card in match_cards[:10]:
            text = card.get_text(separator=" ", strip=True)
            if "vs" in text.lower():
                upcoming.append({"description": text, "source": "espncricinfo"})

        if upcoming:
            return {"source": "espncricinfo", "data": upcoming, "timestamp": _now()}
        return {"source": "cached", "data": _fallback_upcoming(), "timestamp": _now()}

    except Exception as exc:
        logger.warning("ESPNcricinfo upcoming matches fetch failed (%s) — using cached.", exc)
        return {"source": "cached", "data": _fallback_upcoming(), "timestamp": _now()}


def _fallback_upcoming() -> List[Dict]:
    return [
        {"match": "MI vs CSK",   "venue": "Wankhede Stadium",                    "date": "2026-03-25", "time": "19:30 IST"},
        {"match": "RCB vs KKR",  "venue": "M Chinnaswamy Stadium",               "date": "2026-03-26", "time": "19:30 IST"},
        {"match": "SRH vs GT",   "venue": "Rajiv Gandhi International Stadium",  "date": "2026-03-27", "time": "19:30 IST"},
        {"match": "DC vs RR",    "venue": "Arun Jaitley Stadium",                "date": "2026-03-28", "time": "15:30 IST"},
        {"match": "PBKS vs LSG", "venue": "Punjab Cricket Association Stadium",  "date": "2026-03-29", "time": "19:30 IST"},
    ]


# ---------------------------------------------------------------------------
# python-espncricinfo library integration (outside-edge/python-espncricinfo)
# ---------------------------------------------------------------------------

def fetch_live_matches(match_date: Optional[str] = None) -> Dict:
    """
    Fetch live or recent cricket matches using the python-espncricinfo library.

    Uses ``Match.get_recent_matches()`` (via Playwright/WebKit) to retrieve
    match references from ESPN Cricinfo, then extracts lightweight match info
    for each. Falls back to ``fetch_upcoming_matches()`` when the library or
    Playwright is unavailable.

    Args:
        match_date: Optional date string (``YYYY-MM-DD``) for a specific day.
                    Defaults to today.

    Returns:
        Dict with ``source``, ``data`` (list of match summaries), and
        ``timestamp`` keys.
    """
    if not ESPNCRICINFO_LIB_AVAILABLE:
        logger.warning(
            "python-espncricinfo library not available — falling back to "
            "BeautifulSoup scraping."
        )
        return fetch_upcoming_matches()

    try:
        refs: List[MatchRef] = Match.get_recent_matches(date=match_date)
        matches = [
            {
                "match_id": ref.match_id,
                "series_id": ref.series_id,
                "source": "espncricinfo",
            }
            for ref in refs
        ]
        if matches:
            return {"source": "espncricinfo", "data": matches, "timestamp": _now()}
        return {"source": "cached", "data": _fallback_upcoming(), "timestamp": _now()}

    except Exception as exc:
        logger.warning("python-espncricinfo live matches fetch failed (%s) — falling back.", exc)
        return fetch_upcoming_matches()


def fetch_match_details(match_id: int, series_id: int) -> Dict:
    """
    Fetch detailed information for a specific match using the
    python-espncricinfo library.

    Returns match metadata including teams, players, toss, innings, result,
    and venue. Uses Playwright (WebKit) to bypass Akamai CDN restrictions.

    Args:
        match_id: ESPN Cricinfo match object ID (numeric).
        series_id: ESPN Cricinfo series object ID (numeric).

    Returns:
        Dict with ``source``, ``data`` (match detail dict), and
        ``timestamp`` keys. Returns an error dict on failure.
    """
    if not ESPNCRICINFO_LIB_AVAILABLE:
        logger.warning("python-espncricinfo library not available — cannot fetch match details.")
        return {
            "source": "error",
            "error": "python-espncricinfo library not installed",
            "timestamp": _now(),
        }

    try:
        m = Match(match_id, series_id)
        detail: Dict = {
            "match_id": match_id,
            "series_id": series_id,
            "description": getattr(m, "description", None),
            "status": getattr(m, "status", None),
            "match_class": getattr(m, "match_class", None),
            "date": getattr(m, "date", None),
            "result": getattr(m, "result", None),
            "ground_name": getattr(m, "ground_name", None),
            "team_1": getattr(m, "team_1", None),
            "team_1_abbreviation": getattr(m, "team_1_abbreviation", None),
            "team_1_players": getattr(m, "team_1_players", []),
            "team_1_innings": getattr(m, "team_1_innings", None),
            "team_2": getattr(m, "team_2", None),
            "team_2_abbreviation": getattr(m, "team_2_abbreviation", None),
            "team_2_players": getattr(m, "team_2_players", []),
            "team_2_innings": getattr(m, "team_2_innings", None),
            "toss_winner": getattr(m, "toss_winner", None),
            "toss_decision_name": getattr(m, "toss_decision_name", None),
            "current_summary": getattr(m, "current_summary", None),
            "series_name": getattr(m, "series_name", None),
        }
        return {"source": "espncricinfo", "data": detail, "timestamp": _now()}

    except Exception as exc:
        logger.warning("python-espncricinfo match details fetch failed (%s).", exc)
        return {"source": "error", "error": str(exc), "timestamp": _now()}


def fetch_player_details(player_id: Union[int, str]) -> Dict:
    """
    Fetch player profile information using the python-espncricinfo library.

    Retrieves name, date of birth, playing role, batting/bowling style, and
    major teams for the player identified by ``player_id``.

    Args:
        player_id: ESPN Cricinfo player ID (numeric, found in player URLs).

    Returns:
        Dict with ``source``, ``data`` (player detail dict), and
        ``timestamp`` keys. Returns an error dict on failure.
    """
    if not ESPNCRICINFO_LIB_AVAILABLE:
        logger.warning("python-espncricinfo library not available — cannot fetch player details.")
        return {
            "source": "error",
            "error": "python-espncricinfo library not installed",
            "timestamp": _now(),
        }

    try:
        p = Player(str(player_id))
        detail: Dict = {
            "player_id": player_id,
            "name": getattr(p, "name", None),
            "full_name": getattr(p, "full_name", None),
            "date_of_birth": getattr(p, "date_of_birth", None),
            "current_age": getattr(p, "current_age", None),
            "playing_role": getattr(p, "playing_role", None),
            "batting_style": getattr(p, "batting_style", None),
            "bowling_style": getattr(p, "bowling_style", None),
            "major_teams": getattr(p, "major_teams", []),
        }
        return {"source": "espncricinfo", "data": detail, "timestamp": _now()}

    except Exception as exc:
        logger.warning("python-espncricinfo player details fetch failed (%s).", exc)
        return {"source": "error", "error": str(exc), "timestamp": _now()}
