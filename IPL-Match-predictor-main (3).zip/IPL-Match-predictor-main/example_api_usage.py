"""
Example usage of the IPL Match Predictor API endpoints.

This script demonstrates how to use the new v2 endpoints with multi-source
data aggregation and cascading fallback.
"""

import requests
import json

# Base URL - adjust based on your deployment
BASE_URL = "http://localhost:5000"


def print_section(title):
    """Print a formatted section header."""
    print("\n" + "=" * 80)
    print(f" {title}")
    print("=" * 80)


def pretty_print(data):
    """Pretty print JSON data."""
    print(json.dumps(data, indent=2))


def example_1_get_standings():
    """Example 1: Fetch team standings with cascading fallback."""
    print_section("Example 1: Get Team Standings")

    response = requests.get(f"{BASE_URL}/api/v2/standings")
    data = response.json()

    print(f"\nData Source: {data.get('source')}")
    print(f"Timestamp: {data.get('timestamp')}")
    print(f"\nNumber of teams: {len(data.get('data', []))}")

    if data.get('data'):
        print("\nTop 3 teams:")
        for i, team in enumerate(data['data'][:3], 1):
            print(f"{i}. {team.get('name', 'N/A')} - {team.get('points', 0)} points")


def example_2_get_squad():
    """Example 2: Fetch a specific team's squad."""
    print_section("Example 2: Get Team Squad")

    team = "MI"  # Mumbai Indians
    response = requests.get(f"{BASE_URL}/api/v2/squads/{team}")
    data = response.json()

    print(f"\nData Source: {data.get('source')}")
    print(f"\nTeam: {team}")

    if data.get('data'):
        squad_data = data['data']
        if isinstance(squad_data, dict) and 'players' in squad_data:
            print(f"Number of players: {len(squad_data['players'])}")
            print("\nKey players:")
            for player in squad_data['players'][:5]:
                print(f"  - {player.get('name')} ({player.get('role')})")


def example_3_get_injuries():
    """Example 3: Fetch injury updates."""
    print_section("Example 3: Get Injury Updates")

    response = requests.get(f"{BASE_URL}/api/v2/injuries")
    data = response.json()

    print(f"\nData Source: {data.get('source')}")
    print(f"Timestamp: {data.get('timestamp')}")

    if data.get('data'):
        print(f"\nNumber of injury reports: {len(data['data'])}")

        # Handle different data formats
        for i, item in enumerate(data['data'][:3], 1):
            if isinstance(item, dict):
                if 'title' in item:
                    # News API format
                    print(f"\n{i}. {item.get('title')}")
                    print(f"   Source: {item.get('source_name', 'Unknown')}")
                elif 'player' in item:
                    # Cached format
                    print(f"\n{i}. {item.get('player')} ({item.get('team')})")
                    print(f"   Status: {item.get('status')}")


def example_4_get_team_news():
    """Example 4: Fetch general team news."""
    print_section("Example 4: Get General Team News")

    response = requests.get(f"{BASE_URL}/api/v2/team-news")
    data = response.json()

    print(f"\nData Source: {data.get('source')}")

    if data.get('data'):
        print(f"\nNumber of news items: {len(data['data'])}")
        print("\nLatest 3 news items:")

        for i, item in enumerate(data['data'][:3], 1):
            print(f"\n{i}. {item.get('title', 'N/A')}")
            print(f"   {item.get('description', 'No description')[:100]}...")
    else:
        print(f"\nNote: {data.get('note', 'No data available')}")


def example_5_get_summary():
    """Example 5: Fetch comprehensive data summary."""
    print_section("Example 5: Get Comprehensive Summary")

    response = requests.get(f"{BASE_URL}/api/v2/summary")
    data = response.json()

    print("\nData sources used:")
    print(f"  - Standings: {data.get('standings', {}).get('source', 'N/A')}")
    print(f"  - Injuries: {data.get('injuries', {}).get('source', 'N/A')}")
    print(f"  - Team News: {data.get('team_news', {}).get('source', 'N/A')}")

    if '_meta' in data:
        print("\nAvailable sources:")
        for category, sources in data['_meta'].get('sources_available', {}).items():
            print(f"  {category}: {', '.join(sources)}")


def example_6_existing_endpoints():
    """Example 6: Use existing v1 endpoints."""
    print_section("Example 6: Existing V1 Endpoints")

    # Get all teams
    print("\n1. Get all teams:")
    response = requests.get(f"{BASE_URL}/api/teams")
    teams = response.json()
    print(f"   Found {len(teams)} teams")

    # Get specific squad (from cached data)
    print("\n2. Get cached squad for MI:")
    response = requests.get(f"{BASE_URL}/api/squad/MI")
    squad = response.json()
    print(f"   Squad has {len(squad.get('squad', []))} players")

    # Get head-to-head stats
    print("\n3. Get H2H stats for MI vs CSK:")
    response = requests.get(f"{BASE_URL}/api/h2h/MI/CSK")
    h2h = response.json()
    print(f"   Total matches: {h2h.get('total_matches', 'N/A')}")


def main():
    """Run all examples."""
    print("\n" + "=" * 80)
    print(" IPL Match Predictor API Examples")
    print("=" * 80)
    print("\nNote: Make sure the Flask server is running on", BASE_URL)
    print("\nThese examples demonstrate the multi-source data aggregation")
    print("with automatic fallback to available sources.")

    try:
        # Test if server is running
        response = requests.get(f"{BASE_URL}/api/health", timeout=2)
        print(f"\nServer Status: {response.json().get('status', 'unknown')}")

        # Run examples
        example_1_get_standings()
        example_2_get_squad()
        example_3_get_injuries()
        example_4_get_team_news()
        example_5_get_summary()
        example_6_existing_endpoints()

        print("\n" + "=" * 80)
        print(" All examples completed successfully!")
        print("=" * 80 + "\n")

    except requests.exceptions.ConnectionError:
        print("\nError: Could not connect to the server.")
        print(f"Please make sure the Flask app is running on {BASE_URL}")
        print("\nTo start the server, run:")
        print("  python -m backend.app")
    except Exception as e:
        print(f"\nError: {e}")


if __name__ == "__main__":
    main()
