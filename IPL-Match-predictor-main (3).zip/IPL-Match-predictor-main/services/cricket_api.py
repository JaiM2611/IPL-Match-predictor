"""
Cricket data service using CricAPI.

Provides dynamically-fetched IPL 2026 data with retry and short-term caching.

Functions:
    get_series_id()      - Fetch IPL 2026 series ID dynamically
    get_schedule()       - Fetch IPL 2026 schedule
    get_points_table()   - Fetch IPL 2026 points table
    get_live_matches()   - Fetch currently live matches
    get_team_info()      - Fetch all cricket teams

All responses are JSON-structured with 'source', 'data', and 'timestamp' keys.
"""

import logging
import os
import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import requests

logger = logging.getLogger(__name__)

# ── API configuration ────────────────────────────────────────────────────────

CRIC_API_BASE = "https://api.cricapi.com/v1"
CRIC_API_KEY = os.environ.get("CRIC_API_KEY", "f87d1825-d266-416f-b92e-c8a95bb07458")

HEADERS = {
    "User-Agent": "IPL-Match-Predictor/1.0",
    "Accept": "application/json",
}

# ── Short-term in-process cache (30-60 s TTL) ────────────────────────────────

_CACHE: Dict[str, Dict[str, Any]] = {}

# TTLs in seconds
_CACHE_TTL: Dict[str, int] = {
    "series_id": 3600,      # series ID rarely changes — cache for 1 hour
    "schedule": 60,         # schedule: 60 s
    "points_table": 60,     # points table: 60 s
    "live_matches": 30,     # live data: 30 s (most time-sensitive)
    "team_info": 60,        # team list: 60 s
}


def _cache_get(key: str) -> Optional[Any]:
    entry = _CACHE.get(key)
    if entry is None:
        return None
    if time.time() - entry["time"] > _CACHE_TTL.get(key, 60):
        return None
    return entry["value"]


def _cache_set(key: str, value: Any) -> None:
    _CACHE[key] = {"value": value, "time": time.time()}


# ── Internal helpers ──────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _get(url: str, params: Dict, retries: int = 2, timeout: int = 10) -> Optional[Dict]:
    """
    Perform a GET request with automatic retries.

    Args:
        url:     Full request URL.
        params:  Query parameters dict.
        retries: Number of attempts before giving up (default 2).
        timeout: Per-request timeout in seconds.

    Returns:
        Parsed JSON dict or None on failure.
    """
    for attempt in range(1, retries + 1):
        try:
            logger.debug("GET %s (attempt %d/%d)", url, attempt, retries)
            response = requests.get(url, params=params, headers=HEADERS, timeout=timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as exc:
            logger.warning("Request failed (attempt %d/%d): %s", attempt, retries, exc)
            if attempt < retries:
                time.sleep(1)
    return None


def _ok(payload: Optional[Dict]) -> bool:
    """Return True if *payload* looks like a successful CricAPI response."""
    return bool(payload and payload.get("status") == "success" and "data" in payload)


# ── Public API ────────────────────────────────────────────────────────────────

def get_series_id() -> Optional[str]:
    """
    Fetch the IPL 2026 series ID dynamically from the CricAPI series search.

    The result is cached for 1 hour to avoid hammering the search endpoint.

    Returns:
        Series ID string (e.g. "d5a498c8-7596-4b93-8ab0-e0efc3345312") or None.
    """
    cached = _cache_get("series_id")
    if cached:
        logger.debug("series_id from cache: %s", cached)
        return cached

    url = f"{CRIC_API_BASE}/series"
    params = {"apikey": CRIC_API_KEY, "search": "IPL 2026"}

    payload = _get(url, params)
    if not _ok(payload):
        logger.warning("get_series_id: no valid response from CricAPI")
        return None

    series_list = payload["data"]
    if not isinstance(series_list, list):
        logger.warning("get_series_id: unexpected data format: %r", type(series_list))
        return None

    # Pick the first result that mentions IPL / Indian Premier League
    series_id: Optional[str] = None
    for series in series_list:
        name = (series.get("name") or "").lower()
        if "ipl" in name or "indian premier league" in name:
            series_id = series.get("id")
            break

    # Fall back to the very first result if no IPL-specific match found
    if not series_id and series_list:
        series_id = series_list[0].get("id")

    if series_id:
        _cache_set("series_id", series_id)
        logger.info("get_series_id: resolved to %s", series_id)
    else:
        logger.warning("get_series_id: could not extract a series ID from response")

    return series_id


def get_schedule() -> Dict:
    """
    Fetch the IPL 2026 match schedule.

    Uses /series_info with the dynamically-resolved series ID.
    Response is cached for 60 seconds.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys.
    """
    cached = _cache_get("schedule")
    if cached:
        return cached

    series_id = get_series_id()
    if not series_id:
        result = {
            "source": "cric_api",
            "data": [],
            "error": "Could not resolve IPL 2026 series ID",
            "timestamp": _now(),
        }
        return result

    url = f"{CRIC_API_BASE}/series_info"
    params = {"apikey": CRIC_API_KEY, "id": series_id}

    payload = _get(url, params)

    if not _ok(payload):
        result = {
            "source": "cric_api",
            "data": [],
            "error": "Failed to fetch schedule from CricAPI",
            "timestamp": _now(),
        }
        return result

    series_data = payload["data"]
    match_list = series_data.get("matchList", []) or series_data.get("matchlist", [])

    matches = []
    for m in match_list:
        matches.append({
            "id": m.get("id", ""),
            "name": m.get("name", ""),
            "status": m.get("status", ""),
            "venue": m.get("venue", ""),
            "date": m.get("date", ""),
            "dateTimeGMT": m.get("dateTimeGMT", ""),
            "teams": m.get("teams", []),
            "matchType": m.get("matchType", ""),
        })

    result = {
        "source": "cric_api",
        "series_id": series_id,
        "data": matches,
        "timestamp": _now(),
    }
    _cache_set("schedule", result)
    return result


def get_points_table() -> Dict:
    """
    Fetch the IPL 2026 points table.

    Uses /series_points with the dynamically-resolved series ID.
    Response is cached for 60 seconds.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys.
    """
    cached = _cache_get("points_table")
    if cached:
        return cached

    series_id = get_series_id()
    if not series_id:
        result = {
            "source": "cric_api",
            "data": [],
            "error": "Could not resolve IPL 2026 series ID",
            "timestamp": _now(),
        }
        return result

    url = f"{CRIC_API_BASE}/series_points"
    params = {"apikey": CRIC_API_KEY, "id": series_id}

    payload = _get(url, params)

    if not _ok(payload):
        result = {
            "source": "cric_api",
            "data": [],
            "error": "Failed to fetch points table from CricAPI",
            "timestamp": _now(),
        }
        return result

    raw_table = payload["data"]
    if isinstance(raw_table, dict):
        rows = raw_table.get("points_table", []) or raw_table.get("pointsTable", [])
    elif isinstance(raw_table, list):
        rows = raw_table
    else:
        rows = []

    table = []
    for row in rows:
        table.append({
            "team": row.get("teamName", row.get("team_name", row.get("team", ""))),
            "shortName": row.get("shortName", row.get("team_short", "")),
            "matches": _safe_int(row.get("matchesPlayed", row.get("played", row.get("matches")))),
            "wins": _safe_int(row.get("matchesWon", row.get("won", row.get("wins")))),
            "losses": _safe_int(row.get("matchesLost", row.get("lost", row.get("losses")))),
            "noResult": _safe_int(row.get("matchesNoResult", row.get("nr"))),
            "points": _safe_int(row.get("points", row.get("pts"))),
            "nrr": _safe_float(row.get("nrr", row.get("netRunRate"))),
        })

    result = {
        "source": "cric_api",
        "series_id": series_id,
        "data": table,
        "timestamp": _now(),
    }
    _cache_set("points_table", result)
    return result


def get_live_matches() -> Dict:
    """
    Fetch currently live cricket matches.

    Uses /currentMatches endpoint.
    Response is cached for 30 seconds (most time-sensitive endpoint).

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys.
    """
    cached = _cache_get("live_matches")
    if cached:
        return cached

    url = f"{CRIC_API_BASE}/currentMatches"
    params = {"apikey": CRIC_API_KEY}

    payload = _get(url, params)

    if not _ok(payload):
        result = {
            "source": "cric_api",
            "data": [],
            "error": "Failed to fetch live matches from CricAPI",
            "timestamp": _now(),
        }
        return result

    raw_matches = payload["data"]
    if not isinstance(raw_matches, list):
        raw_matches = []

    matches = []
    for m in raw_matches:
        score_list = m.get("score", []) or []
        matches.append({
            "id": m.get("id", ""),
            "name": m.get("name", ""),
            "status": m.get("status", ""),
            "venue": m.get("venue", ""),
            "date": m.get("date", ""),
            "dateTimeGMT": m.get("dateTimeGMT", ""),
            "teams": m.get("teams", []),
            "teamInfo": m.get("teamInfo", []),
            "score": score_list,
            "tossWinner": m.get("tossWinner", ""),
            "tossChoice": m.get("tossChoice", ""),
            "matchWinner": m.get("matchWinner", ""),
            "matchType": m.get("matchType", ""),
            "series_id": m.get("series_id", ""),
        })

    result = {
        "source": "cric_api",
        "data": matches,
        "timestamp": _now(),
    }
    _cache_set("live_matches", result)
    return result


def get_team_info() -> Dict:
    """
    Fetch a list of all cricket teams from CricAPI.

    Uses /teams endpoint.
    Response is cached for 60 seconds.

    Returns:
        Dict with 'source', 'data', and 'timestamp' keys.
    """
    cached = _cache_get("team_info")
    if cached:
        return cached

    url = f"{CRIC_API_BASE}/teams"
    params = {"apikey": CRIC_API_KEY}

    payload = _get(url, params)

    if not _ok(payload):
        result = {
            "source": "cric_api",
            "data": [],
            "error": "Failed to fetch teams from CricAPI",
            "timestamp": _now(),
        }
        return result

    raw_teams = payload["data"]
    if not isinstance(raw_teams, list):
        raw_teams = []

    teams = []
    for t in raw_teams:
        teams.append({
            "id": t.get("id", ""),
            "name": t.get("name", ""),
            "shortName": t.get("shortname", t.get("short_name", t.get("shortName", ""))),
            "img": t.get("img", ""),
        })

    result = {
        "source": "cric_api",
        "data": teams,
        "timestamp": _now(),
    }
    _cache_set("team_info", result)
    return result


# ── Utility helpers (module-level, used internally) ───────────────────────────

def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (ValueError, TypeError, AttributeError):
        return default


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (ValueError, TypeError, AttributeError):
        return default
