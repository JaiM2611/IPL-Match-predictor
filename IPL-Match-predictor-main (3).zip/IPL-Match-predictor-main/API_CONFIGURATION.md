# API Configuration Guide

This document explains how to configure and use the multi-source IPL data API endpoints.

## Overview

The IPL Match Predictor now supports multiple data sources with automatic fallback mechanisms:

### Data Sources by Category

#### 1. Team Standings & Squads
- **Primary:** Cric API (https://api.cricapi.com/)
- **Backup:** FreeWebAPI Cricket API (https://freeapi.app/)
- **Fallback:** ESPNcricinfo web scraping (existing)

#### 2. Injury Updates & Team News
- **Primary:** General News API (https://newsapi.org/)
- **Backup:** GNews API (https://gnews.io/)
- **Additional Backup:** TheSportsDB (https://www.thesportsdb.com/)
- **Fallback:** ESPNcricinfo web scraping (existing)

## Environment Variables

To enable the API integrations, set the following environment variables:

```bash
# Cric API (for standings and squads)
export CRIC_API_KEY="f87d1825-d266-416f-b92e-c8a95bb07458"

# IPL 2026 Series ID (optional - defaults to "1440307")
# Set this if you need to use a different series ID format
export IPL_2026_SERIES_ID="1440307"  # Can also try: "ipl-2026", "indian-premier-league-2026", etc.

# News API (for injury updates and team news)
export NEWS_API_KEY="a97d0c94bd7e48fd8e254bb044083c96"

# GNews API (backup for news)
export GNEWS_API_KEY="7c072c0decc8bae0909153b433431a56"

# TheSportsDB (optional - free tier available)
export THESPORTSDB_API_KEY="123"  # '3' is the free tier key
```

### Getting API Keys

1. **Cric API**: Sign up at https://www.cricapi.com/
2. **News API**: Register at https://newsapi.org/register
3. **GNews API**: Get your key at https://gnews.io/
4. **TheSportsDB**: Free tier available, or get a key at https://www.thesportsdb.com/api.php

## API Endpoints

### New V2 Endpoints (Multi-Source)

All V2 endpoints return data with source attribution and automatic fallback.

#### 1. Get Team Standings

```
GET /api/v2/standings
```

**Response Format:**
```json
{
  "source": "cric_api",
  "data": [
    {
      "team": "MI",
      "name": "Mumbai Indians",
      "matches": 10,
      "wins": 7,
      "losses": 3,
      "points": 14,
      "nrr": 0.832
    },
    ...
  ],
  "timestamp": "2026-03-28T18:00:00Z"
}
```

#### 2. Get Team Squads

```
GET /api/v2/squads           # All teams
GET /api/v2/squads/MI        # Specific team
```

**Response Format:**
```json
{
  "source": "cric_api",
  "data": {
    "MI": {
      "team": "MI",
      "name": "Mumbai Indians",
      "players": [
        {
          "name": "Rohit Sharma",
          "role": "Batsman",
          "is_overseas": false
        },
        ...
      ]
    }
  },
  "timestamp": "2026-03-28T18:00:00Z"
}
```

#### 3. Get Injury Updates

```
GET /api/v2/injuries
```

**Response Format:**
```json
{
  "source": "news_api",
  "data": [
    {
      "title": "Jasprit Bumrah ruled out with ankle injury",
      "description": "...",
      "url": "https://...",
      "published_at": "2026-03-27T10:30:00Z",
      "source_name": "ESPN"
    },
    ...
  ],
  "timestamp": "2026-03-28T18:00:00Z",
  "count": 5
}
```

#### 4. Get General Team News

```
GET /api/v2/team-news
```

**Response Format:**
```json
{
  "source": "news_api",
  "data": [
    {
      "title": "MI announces new team strategy",
      "description": "...",
      "url": "https://...",
      "published_at": "2026-03-28T12:00:00Z",
      "source_name": "Cricbuzz",
      "image_url": "https://..."
    },
    ...
  ],
  "timestamp": "2026-03-28T18:00:00Z",
  "count": 15
}
```

#### 5. Get Comprehensive Summary

```
GET /api/v2/summary
```

Returns all data (standings, injuries, team news) in one request.

**Response Format:**
```json
{
  "standings": { ... },
  "injuries": { ... },
  "team_news": { ... },
  "_meta": {
    "description": "Comprehensive IPL data from multiple sources",
    "sources_available": {
      "standings": ["Cric API", "FreeWebAPI", "ESPNcricinfo"],
      "injuries": ["News API", "GNews API", "TheSportsDB", "ESPNcricinfo"],
      "team_news": ["News API", "GNews API"]
    }
  }
}
```

### Existing V1 Endpoints

All existing endpoints remain unchanged:

- `GET /api/teams` - Get all team information
- `GET /api/venues` - Get all venues
- `GET /api/squad/<team>` - Get squad from cached data
- `GET /api/h2h/<team1>/<team2>` - Get head-to-head stats
- `POST /api/predict` - Get match prediction
- `GET /api/injuries` - ESPNcricinfo injury data (V1)
- `GET /api/points-table` - ESPNcricinfo points table (V1)
- `GET /api/upcoming-matches` - ESPNcricinfo upcoming matches

## Fallback Behavior

### How Fallback Works

The system tries each data source in priority order:

1. **First Source Attempt**: Try the primary API
2. **If Failed**: Automatically try the backup API
3. **If All APIs Fail**: Fall back to cached/scraped data
4. **If Everything Fails**: Return error with "N/A" status

### Source Attribution

Every response includes a `source` field indicating which data source was used:

- `"cric_api"` - Data from Cric API
- `"freewebapi"` - Data from FreeWebAPI
- `"news_api"` - Data from News API
- `"gnews_api"` - Data from GNews API
- `"thesportsdb"` - Data from TheSportsDB
- `"espncricinfo"` - Data from ESPNcricinfo web scraping
- `"cached"` - Cached/fallback data
- `"N/A"` - All sources failed

### Example: Cascading Fallback for Standings

```
1. Try Cric API → Failed (API key not configured)
2. Try FreeWebAPI → Failed (Network error)
3. Try ESPNcricinfo → Success!
   Response: { "source": "espncricinfo", "data": [...] }
```

## Error Handling

### Missing API Keys

If an API key is not configured, that source will be skipped:

```json
{
  "source": "cached",
  "data": [...],
  "note": "Live data unavailable - API keys not configured"
}
```

### All Sources Failed

If all sources fail:

```json
{
  "source": "N/A",
  "data": [],
  "error": "All data sources unavailable",
  "note": "Information not available from any configured source."
}
```

## Development & Testing

### Local Testing Without API Keys

The system will gracefully fall back to cached data if no API keys are configured, allowing for local development and testing.

### Testing Individual Sources

To test individual API clients:

```python
from backend import cric_api_client
from backend import news_api_client

# Test Cric API
standings = cric_api_client.fetch_standings()
print(standings)

# Test News API
injuries = news_api_client.fetch_injury_updates()
print(injuries)
```

### Logging

All API client modules use Python logging. Set log level to INFO or DEBUG to see detailed fallback behavior:

```python
import logging
logging.basicConfig(level=logging.INFO)
```

## Deployment

### Heroku Deployment

Set environment variables in Heroku:

```bash
heroku config:set CRIC_API_KEY="your-key"
heroku config:set NEWS_API_KEY="your-key"
heroku config:set GNEWS_API_KEY="your-key"
```

### Docker Deployment

Add environment variables to your docker-compose.yml or pass them at runtime:

```yaml
environment:
  - CRIC_API_KEY=${CRIC_API_KEY}
  - NEWS_API_KEY=${NEWS_API_KEY}
  - GNEWS_API_KEY=${GNEWS_API_KEY}
```

## Rate Limits & Considerations

- **News API Free Tier**: 100 requests/day
- **GNews API Free Tier**: 100 requests/day
- **Cric API**: Varies by plan
- **TheSportsDB Free Tier**: Limited functionality

Consider implementing caching to reduce API calls and stay within rate limits.

## Troubleshooting

### "All sources failed" Error

1. Check API key configuration
2. Verify network connectivity
3. Check API service status
4. Review logs for specific error messages

### Slow Response Times

- Some sources may be slower than others
- Consider implementing request timeouts (already set to 10 seconds)
- Use caching for frequently accessed data

### Incorrect Data Format

- Different APIs may return data in different formats
- The aggregator module normalizes the data
- If you see formatting issues, check the client module for that specific API
